"""Read-only workbook audit, independent of the forecast model.

The workbook is never refreshed or saved. Optional prior-source/calendar
comparisons are diagnostics only; they do not amend any shared value.
"""
import argparse
import collections
import csv
from datetime import date, datetime
import hashlib
import json
import math
from pathlib import Path
from statistics import mean
import xml.etree.ElementTree as ET
from zipfile import ZipFile
from zoneinfo import ZoneInfo

import openpyxl


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(workbook, *, as_of=date(2026, 10, 30), calendar=None, prior_source=None):
    cached = openpyxl.load_workbook(workbook, read_only=True, data_only=True)
    ws = cached['Worksheet']
    values = list(ws.values)
    metadata = {r[0]: r[1] for r in values[:5]}
    expected_headers = ('Date', 'PX_LAST', 'PX_BID')
    if tuple(values[6]) != expected_headers:
        raise ValueError('Unexpected source headers')
    rows = []
    issues = []
    for excel_row, raw in enumerate(values[7:], 8):
        dt, last, bid = raw
        if not isinstance(dt, datetime):
            issues.append({'row': excel_row, 'issue': 'Invalid cached date'})
            continue
        for column, value in [('PX_LAST', last), ('PX_BID', bid)]:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                issues.append({'row': excel_row, 'column': column, 'issue': 'Missing/nonpositive/nonfinite numeric value'})
        rows.append((dt.date(), last, bid))
    dates = [r[0] for r in rows]
    count = collections.Counter(dates)
    duplicates = [str(d) for d, n in count.items() if n != 1]
    future = [str(d) for d in dates if d > as_of]
    weekend = [str(d) for d in dates if d.weekday() >= 5]
    if duplicates or future or weekend:
        issues.append({'issue': 'Duplicate/future/weekend dates', 'duplicates': duplicates, 'future': future, 'weekend': weekend})
    with ZipFile(workbook) as archive:
        ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        root = ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
        formulas = []
        for cell in root.findall('.//s:c', ns):
            formula = cell.find('s:f', ns)
            if formula is not None:
                cache = cell.find('s:v', ns)
                formulas.append({'cell': cell.attrib['r'], 'formula': formula.text,
                                 'array_range': formula.attrib.get('ref'),
                                 'cached_value_present': cache is not None and cache.text is not None})
        external_links = [n for n in archive.namelist() if n.startswith('xl/externalLinks/')]
    result = {
        'scope': 'READ_ONLY_CACHED_VALUES_NO_REFRESH_NO_SOURCE_SUBSTITUTION',
        'source_file': workbook.name,
        'sha256': sha(workbook),
        'bytes': workbook.stat().st_size,
        'client_as_of_date': str(as_of),
        'sheets': cached.sheetnames,
        'sheet': ws.title,
        'header_row': 7,
        'data_range': f'A8:C{ws.max_row}',
        'source_metadata': {k: v.isoformat() if isinstance(v, datetime) else v for k, v in metadata.items()},
        'chosen_price_field': 'PX_LAST',
        'excluded_price_field': 'PX_BID',
        'chosen_unit': 'S&P 500 price index points; Currency=USD is source metadata, not USD per share',
        'row_count': len(rows),
        'unique_dates': len(count),
        'start_date': str(min(dates)),
        'end_date': str(max(dates)),
        'strict_descending_order': all(a > b for a, b in zip(dates, dates[1:])),
        'calendar_days_after_latest_observation': (as_of - max(dates)).days,
        'duplicate_dates': duplicates,
        'future_dates': future,
        'weekend_dates': weekend,
        'gaps_calendar_days_counts': dict(sorted(collections.Counter((a-b).days for a, b in zip(dates, dates[1:])).items())),
        'formulas': formulas,
        'external_link_parts': external_links,
        'workbook_modified_property': str(cached.properties.modified),
        'source_interpretation': 'Workbook labels SPX Index and contains a Bloomberg BDH formula with Quote=C and Days=T. This is source metadata evidence, not independent vendor authentication.',
        'publication_time': None,
        'original_retrieval_time': None,
        'historical_vintage_time': None,
        'availability_note': 'Workbook file properties and price dates do not establish historical publication or vintage availability. Cached values are a group-supplied snapshot.',
        'issues': issues,
    }
    shared = {d: p for d, p, _ in rows}
    if calendar:
        with calendar.open(newline='') as stream:
            sessions = {date.fromisoformat(r['session_date']) for r in csv.DictReader(stream)}
        first = max(min(shared), min(sessions))
        last = min(max(shared), max(sessions))
        actual = {d for d in shared if first <= d <= last}
        expected = {d for d in sessions if first <= d <= last}
        result['calendar_comparison'] = {
            'calendar_file': calendar.name, 'sha256': sha(calendar),
            'range_start': str(first), 'range_end': str(last),
            'observed_sessions': len(actual), 'expected_sessions': len(expected),
            'missing_sessions': sorted(map(str, expected-actual)),
            'unexpected_sessions': sorted(map(str, actual-expected)),
            'earlier_calendar_coverage': 'Before the saved calendar start, only date validity, ordering and weekend checks were performed.',
        }
    if prior_source:
        raw = json.loads(prior_source.read_text())['chart']['result'][0]
        old = {datetime.fromtimestamp(t, ZoneInfo('America/New_York')).date(): float(p)
               for t, p in zip(raw['timestamp'], raw['indicators']['quote'][0]['close']) if p is not None}
        common = sorted(d for d in set(shared) & set(old) if d.year < 2026)
        differences = [(d, shared[d]-old[d]) for d in common]
        material = [(d, delta) for d, delta in differences if abs(delta) > .005]
        result['prior_source_comparison'] = {
            'scope': 'Diagnostic only, pre-2026 prices; prior source is not a model input and is not distributed in this package',
            'prior_source_file': prior_source.name, 'prior_source_sha256': sha(prior_source),
            'common_dates': len(common), 'start_date': str(min(common)), 'end_date': str(max(common)),
            'mean_absolute_difference_points': mean(abs(delta) for _, delta in differences),
            'maximum_absolute_difference_points': max(abs(delta) for _, delta in differences),
            'difference_above_0_005_points_count': len(material),
            'difference_above_0_01_points_count': sum(abs(delta) > .01 for _, delta in differences),
            'differences_above_0_005_points': [{'date': str(d), 'shared_minus_prior_points': delta} for d, delta in material],
            'policy': 'Retain every shared PX_LAST value unchanged. Differences are not resolved by replacing or averaging sources.',
        }
    result['basic_structure_pass'] = not issues and result['strict_descending_order']
    cached.close()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workbook', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--calendar', type=Path)
    parser.add_argument('--prior-source', type=Path)
    parser.add_argument('--as-of', type=date.fromisoformat, default=date(2026, 10, 30))
    args = parser.parse_args()
    result = audit(args.workbook, as_of=args.as_of, calendar=args.calendar, prior_source=args.prior_source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
    print(json.dumps({'rows': result['row_count'], 'range': [result['start_date'], result['end_date']],
                      'basic_structure_pass': result['basic_structure_pass'], 'issues': result['issues']}))


if __name__ == '__main__':
    main()
