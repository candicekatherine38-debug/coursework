"""Independent input-boundary checks using altered copies of the group workbook."""
from datetime import datetime
from pathlib import Path
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from sp500_review.data import read_workbook, build_dataset

SOURCE = ROOT / "data/SP500 Historical Price Table (2004-2026).xlsx"
NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def altered_workbook(destination, action):
    """Modify only a temporary copy's XML; never open or save the original."""
    with ZipFile(SOURCE) as original, ZipFile(destination, "w", ZIP_DEFLATED) as changed:
        for name in original.namelist():
            payload = original.read(name)
            if name == "xl/worksheets/sheet1.xml":
                tree = ET.fromstring(payload)
                action(tree)
                payload = ET.tostring(tree, encoding="utf-8", xml_declaration=True)
            changed.writestr(name, payload)


class ReviewBoundaryTests(unittest.TestCase):
    def test_cached_prices_survive_without_bloomberg_formula(self):
        expected, _ = read_workbook(SOURCE)
        def remove_formula(tree):
            cell = tree.find(".//s:c[@r='A8']", NS)
            cell.remove(cell.find("s:f", NS))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "without_formula.xlsx"
            altered_workbook(path, remove_formula)
            actual, _ = read_workbook(path)
        self.assertEqual(actual, expected)
        self.assertEqual(len(actual), 5487)

    def test_bid_is_not_used_as_last_price(self):
        expected, _ = read_workbook(SOURCE)
        def change_bid(tree):
            for cell in tree.findall(".//s:c", NS):
                address = cell.attrib["r"]
                if address.startswith("C") and int(address[1:]) >= 8:
                    cell.find("s:v", NS).text = "1.0"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "changed_bid.xlsx"
            altered_workbook(path, change_bid)
            actual, _ = read_workbook(path)
        self.assertEqual([(r["date"], r["PX_LAST"]) for r in expected],
                         [(r["date"], r["PX_LAST"]) for r in actual])
        self.assertTrue(all(r["PX_BID"] == 1 for r in actual))

    def test_missing_date_cell_cannot_silently_drop_price(self):
        def remove_date(tree):
            # This early row predates the saved calendar coverage. The importer
            # itself must detect the missing date, not rely on calendar checks.
            row = tree.find(".//s:row[@r='5490']", NS)
            row.remove(row.find("s:c[@r='A5490']", NS))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "missing_date.xlsx"
            altered_workbook(path, remove_date)
            with self.assertRaisesRegex(ValueError, "INVALID_DATE_CACHE"):
                read_workbook(path)

    def test_post_last_target_prices_cannot_change_modelling_rows(self):
        expected, _, _ = build_dataset(ROOT, SOURCE)
        threshold = (datetime(2026, 1, 3) - datetime(1899, 12, 30)).days
        changed_count = []
        def alter_future(tree):
            for row in tree.findall("s:sheetData/s:row", NS):
                number = int(row.attrib["r"])
                if number < 8:
                    continue
                date_cell = row.find(f"s:c[@r='A{number}']/s:v", NS)
                if float(date_cell.text) >= threshold:
                    last = row.find(f"s:c[@r='B{number}']/s:v", NS)
                    last.text = str(float(last.text) * 3)
                    changed_count.append(number)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "altered_2026.xlsx"
            altered_workbook(path, alter_future)
            actual, _, _ = build_dataset(ROOT, path, allow_source_change=True)
        self.assertGreater(len(changed_count), 100)
        self.assertEqual(actual, expected)
        self.assertTrue(all(row["forecast_origin"][:4] < "2026" for row in actual))


if __name__ == "__main__":
    unittest.main()
