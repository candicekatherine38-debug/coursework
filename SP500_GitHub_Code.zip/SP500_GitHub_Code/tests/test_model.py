"""Synthetic integrity checks; no synthetic values enter reported backtests."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import math
from pathlib import Path
import sys
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from sp500_review.features import generate, POOL
from sp500_review.model import predict


def fixtures():
    rng = np.random.default_rng(91821)
    close = pd.Series(2000*np.exp(np.cumsum(rng.normal(.0002, .011, 950))),
                      index=pd.bdate_range("2016-01-01", periods=950))
    frame = generate(close)
    rows = []
    for number in range(110):
        i = 70+5*number
        origin = datetime(2017, 1, 6, 12, tzinfo=timezone.utc)+timedelta(weeks=number)
        baseline_time = origin-timedelta(hours=15)
        target_time = origin+timedelta(days=7, hours=9)
        rows.append({
            "sample_id": origin.isoformat(), "forecast_origin": origin.isoformat(),
            "baseline_time": baseline_time.isoformat(), "target_time": target_time.isoformat(),
            "feature_assumed_available_time": (origin-timedelta(minutes=30)).isoformat(),
            "label_assumed_available_time": (target_time+timedelta(hours=14, minutes=30)).isoformat(),
            "baseline_index_level": float(close.iloc[i]), "target_index_level": float(close.iloc[i+6]),
            "y_log_return": math.log(float(close.iloc[i+6]/close.iloc[i])),
            "historical_feature_values": frame.iloc[i].to_dict()})
    return close, rows


class ModelIntegrityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.close, cls.rows = fixtures()
        cls.current = cls.rows[-1]
        cls.training = cls.rows[:-2]
        cls.point, cls.details = predict(cls.training, cls.current)

    def test_future_prices_cannot_change_past_factors(self):
        full = generate(self.close)
        changed = self.close.copy()
        changed.iloc[700:] *= 3
        altered = generate(changed)
        np.testing.assert_array_equal(full.iloc[:700].to_numpy(), altered.iloc[:700].to_numpy())
        truncated = generate(self.close.iloc[:700])
        np.testing.assert_array_equal(full.iloc[:700].to_numpy(), truncated.to_numpy())

    def test_current_outcome_is_not_an_input(self):
        current = deepcopy(self.current)
        current.pop("target_index_level")
        current.pop("y_log_return")
        without, _ = predict(self.training, current)
        current["target_index_level"] = -1e300
        current["y_log_return"] = float("nan")
        poisoned, _ = predict(self.training, current)
        self.assertEqual(without, self.point)
        self.assertEqual(poisoned, self.point)

    def test_component_points_reconstruct_from_saved_coefficients(self):
        reconstructed = []
        for name in ["huber", "lad"]:
            part = self.details[name]
            z = [(self.current["historical_feature_values"][n]-m)/s for n, m, s in zip(
                part["features"], part["scaler"]["center"], part["scaler"]["scale"])]
            response = part["intercept"]+math.fsum(a*b for a,b in zip(part["coefficients"],z))
            if name == "lad":
                response *= part["current_scale_percent"]
            point = self.current["baseline_index_level"]*(1+response/100)
            self.assertAlmostEqual(point, part["forecast"], places=9)
            reconstructed.append(point)
        self.assertAlmostEqual(sum(reconstructed)/2, self.point, places=9)

    def test_immature_training_label_rejected(self):
        bad = deepcopy(self.training)
        bad[0]["label_assumed_available_time"] = self.current["forecast_origin"]
        with self.assertRaisesRegex(ValueError, "NOT_MATURE"):
            predict(bad, self.current)

    def test_training_interval_overlap_rejected(self):
        bad = deepcopy(self.training)
        bad[0]["target_time"] = self.current["forecast_origin"]
        with self.assertRaisesRegex(ValueError, "OVERLAPS"):
            predict(bad, self.current)

    def test_minimum_training_and_2026_boundary(self):
        with self.assertRaisesRegex(ValueError, "INSUFFICIENT_MATURE"):
            predict(self.training[:103], self.current)
        future = deepcopy(self.current)
        future["forecast_origin"] = "2026-01-09T12:00:00+00:00"
        with self.assertRaisesRegex(ValueError, "2026_RESEARCH"):
            predict(self.training, future)

    def test_prices_must_be_real_positive_unique_and_sorted(self):
        for bad in [pd.Series([1., 0., 2.]), pd.Series([1., np.nan, 2.]),
                    pd.Series([1., 2.], index=[1,1]), pd.Series([1., 2.], index=[2,1])]:
            with self.assertRaises(ValueError):
                generate(bad)

    def test_feature_warmup_and_pool(self):
        frame = generate(self.close)
        self.assertEqual(len(POOL), 134)
        self.assertEqual(frame.shape[1], 136)
        self.assertTrue(frame.iloc[:62].isna().all().all())
        self.assertTrue(np.isfinite(frame.iloc[62:].to_numpy()).all())


if __name__ == "__main__":
    unittest.main()
