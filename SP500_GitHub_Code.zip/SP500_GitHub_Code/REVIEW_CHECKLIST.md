# Group peer review

Complete the record only after actually performing the checks. No member approval is implied by the supplied code or results.

| Question | Evidence to inspect | Reviewer finding |
|---|---|---|
| Are security, price field, units and dates correct? | Original Excel and `data_audit.json` | |
| Can the model be reproduced from this folder alone? | README commands; compare predictions | |
| Are all factors computed only from past closes? | `features.py`; truncation tests | |
| Does training exclude unmatured and overlapping target intervals? | `data.py`, `model.py`, training IDs | |
| Is the current actual target absent from the prediction interface? | `run_review.py`, tests | |
| Can coefficients and scalers reconstruct a chosen forecast? | `fitted_models.jsonl` | |
| Are source changes and the legacy exclusion mask understood? | `MODEL_CARD.md`, audit files | |
| Does the model beat the unchanged-price benchmark consistently? | Predictions, year scores, worst errors | |
| Are the economic mechanism and extra-feature complexity persuasive? | Model card and eventual final report | |
| Are availability/vintage limits and research selection bias disclosed? | Model card and summary | |

Reviewer name/identifier:

Date:

Commands and selected origins actually checked:

Numerical tolerance used:

Issues and proposed changes:

Decision (accept for further research / changes requested / other):

This is a model-review decision, not approval of a final November forecast or permission to submit coursework.
