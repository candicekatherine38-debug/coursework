#!/usr/bin/env python3
"""Reproduce fixed-model group-data review. No download or AI account is used."""
import os
for name in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    os.environ[name] = "1"
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
import argparse
import csv
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import importlib.metadata
import json
import math
import platform
import socket
import time
import traceback
from sp500_review.data import build_dataset, training_rows, write_json, sha
from sp500_review.model import predict, CONFIG
from sp500_review.features import definitions


def score(point, actual):
    p, a = Decimal(str(point)), Decimal(str(actual))
    ape = Decimal(100)*abs(p-a)/a
    return {"ape_percent": float(ape), "score": float(max(Decimal(0), Decimal(50)-5*ape))}


def write_csv(path, rows, columns=None):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def reconstruct(details):
    components = []
    for name in ["huber", "lad"]:
        d = details[name]
        z = [(details["current_feature_values"][n]-c)/s for n, c, s in zip(
            d["features"], d["scaler"]["center"], d["scaler"]["scale"])]
        value = d["intercept"] + math.fsum(a*b for a, b in zip(d["coefficients"], z))
        if name == "lad":
            value *= d["current_scale_percent"]
        components.append(details["baseline"]*(1+value/100))
    return math.fsum(w*p for w, p in zip(details["component_weights"], components))


def summarise(records, name):
    chosen = [r for r in records if r["model"] == name]
    good = [r for r in chosen if r["status"] == "SUCCESS"]
    return {"model": name, "windows": len(chosen), "failed_windows": len(chosen)-len(good),
            "mean_course_score_out_of_50": sum(r["score"] for r in chosen)/len(chosen),
            "MAPE_percent_successful_only": sum(r["ape_percent"] for r in good)/len(good) if good else None,
            "worst_APE_percent": max(r["ape_percent"] for r in good) if good else None,
            "years": {str(y): sum(r["score"] for r in chosen if r["origin"].startswith(str(y))) /
                      sum(r["origin"].startswith(str(y)) for r in chosen) for y in [2024, 2025]}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT/"data/SP500 Historical Price Table (2004-2026).xlsx")
    parser.add_argument("--output", type=Path, default=ROOT/"results_reproduced")
    parser.add_argument("--accept-new-snapshot", action="store_true",
                        help="Explicitly accept a different workbook hash; fixed schema/cohort/model remain unchanged.")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    before = time.perf_counter()
    attempts = []
    def blocked(*a, **kw):
        attempts.append("NETWORK_CALL_BLOCKED")
        raise RuntimeError("NETWORK_DISABLED_FOR_REPRODUCTION")
    socket.socket.connect = blocked
    socket.socket.connect_ex = blocked
    socket.getaddrinfo = blocked
    socket.create_connection = blocked
    pool, raw, audit = build_dataset(ROOT, args.input, args.accept_new_snapshot)
    write_json(out/"data_audit.json", audit)
    write_json(out/"model_specification.json", CONFIG)
    write_json(out/"factor_definitions.json", definitions())
    write_csv(out/"normalized_source.csv", raw)
    origins = [r for r in pool if "2024" <= r["forecast_origin"][:4] <= "2025"]
    if len(origins) != 104:
        raise ValueError("EXPECTED_104_MATCHED_OUTER_ORIGINS")
    write_csv(out/"weekly_features.csv", [{"origin": r["forecast_origin"],
              "baseline_date": r["baseline_date"], **r["historical_feature_values"]} for r in pool])
    records, failures, details_list = [], [], []
    maximum_reconstruction_error = 0.
    with (out/"fitted_models.jsonl").open("w", encoding="utf-8") as details_stream:
        for i, current in enumerate(origins):
            train = training_rows(pool, current)
            common = {"origin": current["forecast_origin"], "baseline_date": current["baseline_date"],
                      "target_date": current["target_date"], "baseline": current["baseline_index_level"],
                      "actual": current["target_index_level"], "training_count": len(train)}
            # Remove the current outcome from the predictor interface.
            predictor_row = {k: v for k, v in current.items() if k not in {"target_index_level", "y_log_return"}}
            points = {"NO_CHANGE": common["baseline"]}
            try:
                point, details = predict(train, predictor_row)
                details["origin"] = current["forecast_origin"]
                maximum_reconstruction_error = max(maximum_reconstruction_error, abs(reconstruct(details)-point))
                if maximum_reconstruction_error > 1e-8:
                    raise ValueError("INDEPENDENT_POINT_RECONSTRUCTION_FAILED")
                details_stream.write(json.dumps(details, allow_nan=False)+"\n")
                details_list.append(details)
                points.update(BLEND_VOL_LAD=point, HUBER_PRICE3=details["huber"]["forecast"],
                              VS_LAD_PRICE3=details["lad"]["forecast"])
            except Exception as exc:
                failures.append({"origin": current["forecast_origin"], "error": str(exc),
                                 "traceback": traceback.format_exc().replace(str(ROOT), "<PACKAGE>")})
                points.update(BLEND_VOL_LAD=None, HUBER_PRICE3=None, VS_LAD_PRICE3=None)
            for name, point in points.items():
                record = {**common, "model": name, "forecast": point,
                          "status": "SUCCESS" if point is not None else "FAILED"}
                record.update(score(point, common["actual"]) if point is not None else {"ape_percent": None, "score": 0.})
                records.append(record)
            if (i+1) % 26 == 0:
                print(f"Completed {i+1}/{len(origins)} matched historical origins", flush=True)
    write_csv(out/"predictions.csv", records)
    names = ["BLEND_VOL_LAD", "HUBER_PRICE3", "VS_LAD_PRICE3", "NO_CHANGE"]
    summary = {"purpose": "FIXED_MODEL_GROUP_DATA_PEER_REVIEW_NOT_FINAL_COURSEWORK_FORECAST",
               "source": args.input.name, "source_sha256": sha(args.input), "models": [summarise(records, n) for n in names],
               "selection": "No tuning or winner selection on this dataset; BLEND_VOL_LAD retained before execution",
               "comparison": "Same104 outer origins and original eligible weekly training cohort as previous project",
               "data_limitations": "Current supplied snapshot, historical publication/vintage times unknown",
               "model_score_years": [2024, 2025], "scored_2026_origins": 0, "final_november_forecast": None,
               "current_outcome_removed_before_prediction": True,
               "max_scalar_reconstruction_error_points": maximum_reconstruction_error,
               "network_attempts": attempts, "all_104_origins_succeeded": not failures}
    write_json(out/"summary.json", summary)
    write_json(out/"failures.json", failures)
    warning_counts = {}
    for d in details_list:
        for w in d["lad"]["fit"]["warnings"]:
            warning_counts[w] = warning_counts.get(w, 0)+1
    write_json(out/"warnings.json", warning_counts)
    from sp500_review.report import write_report
    write_report(out, summary, records)
    write_json(out/"run_environment.json", {"started_at_utc": started,
               "finished_at_utc": datetime.now(timezone.utc).isoformat(), "seconds": time.perf_counter()-before,
               "python": platform.python_version(), "platform": platform.system()+" "+platform.machine(),
               "packages": {n: importlib.metadata.version(n) for n in ["numpy", "scipy", "pandas"]},
               "argv": {"input": args.input.name, "output": out.name, "accept_new_snapshot": args.accept_new_snapshot},
               "source_code_sha256": {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT/"src").rglob("*.py"))},
               "config_sha256": sha(ROOT/"config/model.json"), "network_attempts": attempts})
    print(json.dumps(summary, indent=2))
    if failures:
        raise SystemExit("Review completed with failed forecasts; inspect failures.json")


if __name__ == "__main__":
    main()
