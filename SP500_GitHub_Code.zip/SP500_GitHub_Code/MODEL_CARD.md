# Fixed BLEND_VOL_LAD model

## Prediction contract

S&P 500 price-index level, in index points. Historical origins are Fridays at 07:00 America/New_York. Baseline is the latest completed cash session close. Target is the latest session close at or before next Friday 16:00 New York. This is seven civil days, not a fixed number of future trading sessions. Early closes and holidays use the supplied frozen calendar.

The final coursework target is 2026-11-20 21:00 UTC and information cutoff is 2026-11-13 12:00 UTC. This review package has no final point and intentionally rejects 2026 model origins. Future formal inference needs a separately checked current input and release procedure.

## Features and economic interpretation

`mom20 = log(P[t]/P[t-20])` measures recent trend. `rv20` is the sample standard deviation of the latest20 log returns, annualized by sqrt(252), measuring recent risk. Trend persistence can fail during reversals; risk normalization can fail under sudden regime shifts and does not predict the sign of a shock.

Three additional close-derived features are selected from the fixed134-candidate pool: 75 rolling price statistics across5/10/20/30/60 sessions plus59 lag-price ratios. Formulas are exported to `factor_definitions.json`. These measure trend, range position and balance of past positive/negative price changes; they are price-based proxies, not identified causal economic factors. Core features use original precision. Candidate inputs/outputs use float32 to preserve the original feature engine's convention.

At every origin rank candidates by absolute Spearman correlation with **mature training log returns**, break ties by name, and greedily remove factors with absolute Spearman correlation >=0.95 with an earlier kept factor. Keep the two core features and three selected candidates. No current target enters screening, scaling or prediction. Final coursework still needs a clear economic argument and justification for these extra variables; a historical ranking alone does not establish that justification.

## Fitting and forecast calculation

Training is expanding weekly history with at least104 eligible, mature observations. A training target must end no later than the current baseline, and assumed label availability must precede the origin. Re-estimation uses only these rows. The original cohort begins2016-10-21, with first eligible origin2017-01-27. Fourteen warmup and13 old conflict-related exclusions remain only as a matched-comparison mask. They do not assert that the shared prices are wrong.

Let `g = historical_target / historical_baseline`, and `y = 100*(g-1)`.

Huber fits y on standardized selected features using alpha0.01, epsilon1.35, max500 iterations and gradient tolerance1e-7. Feature scaling uses the training population variance. Slopes receive an L2 penalty; the intercept does not. The joint Huber scale is estimated.

For LAD define `s = max(0.25, 100*rv20*sqrt(6/252))`. Fit normalized response `y/s` with weights `s/g`, normalized to sum1. Minimize `0.5*weighted_absolute_residual + 0.01*sum(abs(slopes))`; the intercept is unpenalized. Standardization uses the same weights. The fixed6-session risk multiplier is a scale normalization, not advance knowledge of future session counts. Predict the normalized response and multiply by current s.

Each component point is `baseline * (1 + predicted_percent_return/100)`. Final point is `0.5*Huber_point + 0.5*LAD_point`. Per-origin coefficients, intercepts, scalers, input features and training IDs are exported so another reviewer can reconstruct both points. Invalid inputs or failed fits are recorded; failed forecasts receive zero score rather than being dropped.

## Interpretation and limitations

The existing model was chosen during earlier exploratory research. This workbook replacement does not provide an independent validation period. Original and shared source prices differ on some dates; no old price is used to override the group source. Additional pre-2016 data is preserved but adds no training origins in this comparison. There is no claim that this is the optimal model for all2004–2026 history.

Source observation dates are not publication timestamps. The historical next-day06:30 New York rule is an assumption. The workbook is a current supplied snapshot, without original historical vintages. Saved calendar schedules are also not a proof of historical announcement availability. These limits prevent strict point-in-time certification.

Software equivalence is tested against the original engine on old inputs. That check proves implementation consistency to a stated tolerance; it does not prove predictive validity, vendor identity or data rights. Solver warnings are saved. The historical score cannot be interpreted as a guaranteed future mark.
