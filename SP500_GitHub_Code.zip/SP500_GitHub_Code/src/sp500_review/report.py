"""Portable static HTML review summary; plots contain no remote resources."""
from html import escape
import json


def chart(records):
    rows = [r for r in records if r["model"] == "BLEND_VOL_LAD"]
    width, height, left, right, top, bottom = 950, 330, 65, 25, 20, 45
    values = [r[k] for r in rows for k in ["actual", "forecast"] if r[k] is not None]
    low, high = min(values)*.98, max(values)*1.02
    def x(i):
        return left+i*(width-left-right)/(len(rows)-1)
    def y(v):
        return top+(high-v)*(height-top-bottom)/(high-low)
    shapes = []
    for j in range(5):
        value = low+(high-low)*j/4
        shapes.append(f'<line x1="{left}" x2="{width-right}" y1="{y(value):.2f}" y2="{y(value):.2f}" stroke="#e2e8f0"/>')
        shapes.append(f'<text x="{left-10}" y="{y(value)+4:.2f}" text-anchor="end">{value:,.0f}</text>')
    for key, color in [("actual", "#334155"), ("forecast", "#2563eb")]:
        points = " ".join(f'{x(i):.2f},{y(r[key]):.2f}' for i, r in enumerate(rows) if r[key] is not None)
        shapes.append(f'<polyline fill="none" stroke="{color}" stroke-width="2" points="{points}"/>')
    for i in [0, 26, 52, 78, 103]:
        shapes.append(f'<text x="{x(i):.2f}" y="{height-12}" text-anchor="middle">{rows[i]["target_date"]}</text>')
    return f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="Forecast and actual index levels across 104 historical weeks">'+"".join(shapes)+"</svg>"


def write_report(out, summary, records):
    table = []
    for m in summary["models"]:
        table.append(f'<tr><td>{escape(m["model"])}</td><td>{m["windows"]}</td>'
                     f'<td>{m["mean_course_score_out_of_50"]:.6f}</td>'
                     f'<td>{m["MAPE_percent_successful_only"]:.4f}%</td>'
                     f'<td>{m["years"]["2024"]:.6f}</td><td>{m["years"]["2025"]:.6f}</td>'
                     f'<td>{m["failed_windows"]}</td></tr>')
    chart_svg = chart(records)
    (out/"forecast_vs_actual.svg").write_text(chart_svg, encoding="utf-8")
    (out/"review.html").write_text('''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>S&P 500 Group Model Review</title>
<style>body{font:16px/1.6 system-ui,sans-serif;color:#172033;background:#f8fafc;margin:0}main{max-width:1080px;margin:40px auto;padding:28px;background:white}h1{font-size:30px;line-height:1.2}h2{font-size:22px;margin-top:32px}p{max-width:90ch}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid #cbd5e1;padding:10px;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#edf2f7}a{color:#1d4ed8}svg{width:100%;font:12px system-ui}code{background:#f1f5f9;padding:2px 5px}.note{color:#475569}</style>
<main><h1>S&amp;P 500 Group Model Review</h1>
<p><strong>Fixed model, shared workbook, reproducible historical comparison.</strong> BLEND_VOL_LAD averages Huber and volatility-normalized LAD forecasts with fixed 50/50 weights. No parameter search or model reselection was performed after importing the group data.</p>
<p>This package supports independent reproduction and peer review within the group. All prices use <strong>PX_LAST</strong> from the shared workbook, with the original model and matched evaluation cohort. These historical results are neither the formal 20 November forecast nor awarded coursework marks.</p>
<h2>Results on the shared data</h2><p>104 weekly origins in 2024–2025; expanding mature training history from the original matched cohort. All component forecasts, targets and benchmark prices are rebuilt from the supplied workbook.</p>
<div style="overflow-x:auto"><table><tr><th>Model</th><th>Weeks</th><th>Mean score /50</th><th>MAPE</th><th>2024 score</th><th>2025 score</th><th>Failures</th></tr>'''+"".join(table)+'''</table></div>
<h2>Forecast and actual index levels</h2><p><span style="color:#2563eb">Blue: fixed blend forecast</span>; <span style="color:#334155">grey: realised historical close</span>. Levels can appear close while weekly errors remain economically material.</p>'''+chart_svg+'''
<h2>What is held fixed</h2><p>The two components, 50/50 blend, 104 minimum training rows, penalty parameters, training-only selection of three price features, two core features, chronological training and 104 evaluation origins are unchanged. Twenty-seven originally excluded origins are retained as a labelled legacy comparison mask, not as a finding that those dates are wrong in the shared workbook.</p>
<h2>Review the evidence</h2><ul><li><a href="predictions.csv">All component, blend and unchanged-price predictions</a></li><li><a href="fitted_models.jsonl">Per-origin coefficients, standardization, feature selection and training IDs</a></li><li><a href="weekly_features.csv">All recomputed weekly features</a></li><li><a href="normalized_source.csv">Cached workbook values in chronological order</a></li><li><a href="summary.json">Machine-readable summary</a> and <a href="data_audit.json">data checks</a></li><li><a href="factor_definitions.json">Factor formulas</a> and <a href="model_specification.json">fixed model specification</a></li><li><a href="run_environment.json">Execution versions and source hashes</a></li></ul>
<h2>Interpretation and limits</h2><p>The workbook covers 31 December 2004 to 22 October 2026. Earlier history is retained but does not add training origins to this matched comparison. Feature calculation stops at 2025-12-31. The final 2025 origin uses its realised 2026-01-02 target for scoring only; no 2026 origin is evaluated. Historical publication times and original vintages are unknown. Next-day 06:30 New York availability is an explicit research assumption.</p>
<p>These 2024–2025 windows were used in prior model research. This is a source-replacement and reproduction exercise, not a new blind validation. Additional price features need an economic and complexity justification in the final coursework. Read <code>REVIEW_CHECKLIST.md</code> and <code>MODEL_CARD.md</code> before interpreting the numbers.</p>
<p class="note">Offline review package. No external scripts, online charts, tracking, Bloomberg refresh or live AI subscription is needed. The formal November forecast and group approval remain pending.</p></main></html>''', encoding="utf-8")
