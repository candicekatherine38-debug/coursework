"""Check the delivered file hashes using the Python standard library."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root/"MANIFEST.json").read_text())
errors = []
for name, expected in manifest["files"].items():
    path = root/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        errors.append(name)
print(json.dumps({"checked_files": len(manifest["files"]), "mismatches": errors, "pass": not errors}, indent=2))
if errors:
    raise SystemExit(1)
